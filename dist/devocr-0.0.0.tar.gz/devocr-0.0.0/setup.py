from setuptools import setup, find_packages

setup(
	name = 'devocr',
	author = 'Devaloy Mukherjee',
	author_email = 'devaloy.mukherjee@gmail.com',
	packages = find_packages()
	)
