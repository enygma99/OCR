from setuptools import setup, find_packages

with open("README.md", "r") as fh:
    long_description = fh.read()

setup(
	name = 'devocr',
	version = '1.0.0',
	author = 'Devaloy Mukherjee',
	author_email = 'devaloy.mukherjee@gmail.com',
	packages = find_packages()
	)
