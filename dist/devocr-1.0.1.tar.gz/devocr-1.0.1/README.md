Optical Character Recognition using Python

Please install the following packages before using this package;
1. Pillow
2. Imagemagick
3. Pytesseract

This package is using Google's tesseract-OCR package for python to convert image data into usable text data.
After importing the package the program can be called by using the ocr() method. This method has no arguements and it returns a json object and also displays the text extracted in a text window.